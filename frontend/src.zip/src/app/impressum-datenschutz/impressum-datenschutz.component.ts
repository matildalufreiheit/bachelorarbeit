import { Component } from '@angular/core';

@Component({
  selector: 'app-impressum-datenschutz',
  templateUrl: './impressum-datenschutz.component.html'
})
export class ImpressumComponent { }

